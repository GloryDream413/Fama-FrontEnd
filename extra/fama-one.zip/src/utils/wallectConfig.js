import { configureChains, createConfig } from 'wagmi'

import { alchemyProvider } from 'wagmi/providers/alchemy'
import { publicProvider } from 'wagmi/providers/public'

import { LedgerConnector } from 'wagmi/connectors/ledger'
import { MetaMaskConnector } from 'wagmi/connectors/metaMask'
import { WalletConnectConnector } from 'wagmi/connectors/walletConnect'
// import { goerli } from 'viem/chains'
import { avalanche, bsc, goerli, mainnet } from '@wagmi/chains'


const { chains, publicClient, webSocketPublicClient } = configureChains(
  [avalanche, bsc, mainnet,goerli],
  [alchemyProvider({ apiKey: 'yourAlchemyApiKey' }), publicProvider()],
)

// Set up wagmi config
export const config = createConfig({
  autoConnect: true,
  connectors: [
    new MetaMaskConnector({ chains }),
    // new CoinbaseWalletConnector({
    //   chains,
    //   options: {
    //     appName: 'wagmi',
    //   },
    // }),
    new LedgerConnector({
      options: {
        enableDebugLogs: true,
        chains,
        // rpc: {
        //   1: 'https://eth-mainnet.alchemyapi.io/v2/yourAlchemyId',
        // },
      },
    }),
    new WalletConnectConnector({
      chains,
      options: {
        projectId: 'c1fecdaa2d99d3e07e8d35e697a3dc25',
      },
    }),
    // new InjectedConnector({
    //   chains,
    //   options: {
    //     name: 'Injected',
    //     shimDisconnect: true,
    //   },
    // }),
  ],
  publicClient,
  webSocketPublicClient,
})

