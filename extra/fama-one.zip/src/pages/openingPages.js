import OpeningSection from '@/Sections/OpeningSection'
import { contractABI, contractAddress, wagmiContractConfig } from '@/contract'
import Layout from '@/layout'
import React from 'react'
import { useContractWrite } from 'wagmi'
import { useContractInfiniteReads } from 'wagmi'
import { useContractEvent } from 'wagmi'
import { useContractRead } from 'wagmi'
import { useContract } from 'wagmi'
import { useWalletClient } from 'wagmi'

export default function OpeningPages() {

  // const { data: walletClient, isError, isLoading } = useWalletClient()
 
  // const contract = useContractRead({
  //   address: contractAddress,
  //   abi: contractABI,
  //   walletClient,
  // })


  // const { write, data, error, isLoading, isError, isSuccess } =
  // useContractWrite({
  //   ...wagmiContractConfig,
  //   functionName: 'deposit',
  //   chainId: 5,
  //   args: [ '0x40426F16818A5b8ce1e4a2ad58279cF309f356cc', 100 ]
  // })
  // const contract = useContractEvent(
  //   {
  //     addressOrName: contractAddress,
  //     contractInterface: contractABI,
  //   },
  //   'deposit',
  //   (event) => console.log(event),
  // )
  // console.log({data})


  


  return (
    <Layout>
      <OpeningSection />
    </Layout>
  )
}
