/* eslint-disable import/named */
import { useQuery } from '@tanstack/react-query';

import { useSelectWeb3 } from '../useSelectWeb3';
import { queryKeys } from './queryConstants';
import axios from 'axios';

// const queryFn = async () => {
//   const backEndData = await fetch('http://127.0.0.1:5000/')
//   console.log({backEndData})
//   // return backEndData
// };

// queryFn()

export const useQueryGetUserInfo = () => {
  const queryKey = [queryKeys.getBackendData];

  const queryFn = async () => {
    const backEndData = await axios.get('http://127.0.0.1:5000/').then(res => {
      console.log(res)
      return res
    })
    console.log({ backEndData })
    return backEndData.wait(5000)
  };

  return useQuery(queryKey, queryFn, {
    // select: ,
    select: (res)=> { console.log(res) },
    onError: (error) => {
      console.log(error);
    },
  });
};

