export const queryKeys = {
  getBackendData:'getBackendData',
};

export const authorizedUsers = [
  '0x40426F16818A5b8ce1e4a2ad58279cF309f356cc'
]

