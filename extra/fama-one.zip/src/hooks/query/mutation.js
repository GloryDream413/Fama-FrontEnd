/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable import/named */
import { useMutation } from '@tanstack/react-query';
import { useSelectWeb3 } from '../useSelectWeb3';
import { ethers } from 'ethers'
import { contractABI, contractAddress } from '@/contract';
import { useContractEvent } from 'wagmi';


const handleReadFunc = () => {

}
const handleWriteFunc = () => {

}

export const useMutationDeposit = () => {
  const { account, APP_CONTRACT } = useSelectWeb3();
  // console.log({ APP_CONTRACT })

  const mutationFn = async () => {
    // const value = ethers.utils.hexlify('0.02');
    // console.log({value})
    // const value = 0.02;
    // const hexValue = ethers.BigNumber.from(1.2)

    // console.log(hexValue);
    // const options = {
    //   gasLimit: 500000
    // }

    

    // const tx = await writeContract({
    //   address: contractAddress,
    //   abi: contractABI,
    //   functionName: 'deposit',
    //   args: [account, 10],
    // })
    // console.log({tx})

    // const tx = await APP_CONTRACT.deposit(account, 1);
    return tx.wait();
  };

  return useMutation(mutationFn, {
    onError: (error) => {
      console.log(error);
    },
  });
};
