import React from "react";
import Graph from "./Graph";
import DataContent from "./DataContent";
import DataTable from "./DataTable";

export default function MainGraph() {
  return (
    <div className="">
      <div className="col-span-3 mt-[41px]">
        <div className="grid grid-cols-1 gap-[20px] w-[90%] lg:grid-cols-2">
          <div className="flex gap-5 justify-between items-center lg:justify-normal">
            <p className="text-14 sm:text-20">All time performance:</p>
            <p className="text-16 sm:text-25 text-number">+122%</p>
          </div>
          <div className="flex gap-5 justify-between items-center lg:justify-normal">
            <p className="text-14 sm:text-20">Month to date performance:</p>
            <p className="text-16 sm:text-25 text-number">+17.2%</p>
          </div>
        </div>
        <Graph />
        <DataContent />
        <DataTable />
      </div>
    </div>
  );
}
