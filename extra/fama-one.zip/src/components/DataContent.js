import React from 'react'

export default function DataContent() {
  return (
    <div className='grid grid-cols-2 gap-[25px] w-[100%] mt-[50px] md:grid-cols-4 md:mt-[36px] md:gap-[10px] md:pl-[30px] '>
        <p className='text-14 sm:text-16'>Vault Capacity:</p>
        <p className='text-14 sm:text-16'>$50,000</p>
        <p className='text-14 sm:text-16'>Average Drawdown:</p>
        <p className='text-14 sm:text-16'>-0.62%</p>
        <p className='text-14 sm:text-16'>Vault Deposits:</p>
        <p className='text-14 sm:text-16'>$25,000 (50% capacity)</p>
        <p className='text-14 sm:text-16'>Avg. Drawdown Occurrence:</p>
        <p className='text-14 sm:text-16'>4.6 per month</p>
    </div>
  )
}
