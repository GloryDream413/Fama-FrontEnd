/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import {
  useContractRead,
  usePrepareContractWrite
} from 'wagmi';

import { contractABI, contractAddress, wagmiContractConfig } from "@/contract";
import { useAccount } from "wagmi";
import { useContractWrite } from 'wagmi';

const Wallet_Data = [
  {
    id: 1,
    title: " Ξ1.344",
  },
  {
    id: 2,
    title: "ETH",
  },
  {
    id: 3,
    title: "$35.55",
  },
  {
    id: 4,
    title: "USDC",
  },
];

const Position_Data = [
  {
    id: 1,
    title: "0",
  },
  {
    id: 2,
    title: "LP Tokens",
  },
  {
    id: 3,
    title: "$0",
  },
  {
    id: 4,
    title: "Est. Value",
  },
];

export default function ManageSection() {

  // const { data, mutate:mutateDeposit } = useMutationDeposit()
  const { address } = useAccount();

  const { data: useContractReadData } = useContractRead({
    ...wagmiContractConfig,
    functionName: 'IpToken',
    watch: true
  })
  // https://goerli.etherscan.io/address/0x6BB762Ab5141A015efD4D6F0723399CAa4A31b07#writeContract#F1

  // {isError}




  const config = usePrepareContractWrite({
    address: contractAddress,
    abi: contractABI,
    functionName: 'deposit',
    // args: [],
    chainId: 420,
    enabled: true,
  })

  const {data : useContractWriteData , write } = useContractWrite(config)

  // const { write, data, error, isLoading, isError, isSuccess } =
  // useContractWrite({
  //   ...wagmiContractConfig,
  //   functionName: 'withdraw',
  //   chainId: 5,
  //   args: 10,
  // })

  // const { data, isError, error,write, writeAsync } = useContractWrite(config)
  // console.log({ write,isError,error, data,useContractReadData })
  // const value = useContractWrite(config)
  // console.log({value})

  // const {data : useWaitForTransactionData, isSuccess} = useWaitForTransaction({
  //   hash: useContractWriteData?.hash
  // })

  // console.log("useContractWriteData:", useContractWriteData);
  // useEffect(() => {
  //   console.log("__________________________");
  //   // console.log("useContractReadData", useContractReadData);
  //   console.log("useContractWriteData:", useContractWriteData);
  //   console.log("useWaitForTransactionData:", useWaitForTransactionData);
  //   console.log("__________________________");
  // }, [ useContractWriteData, useWaitForTransactionData]);


  return (
    <div className="bg-manage-bg px-[25px] pt-[14px] pb-[41px] border-[1px] border-white mt-[41px] rounded-[30px]">
      <p className="text-20 sm:text-25">Manage</p>
      <div className="mt-[11px]">
        <p className="text-16 sm:text-18">Your Wallet:</p>
        <div className="grid grid-cols-2 gap-[21px] mt-[47px]">
          {Wallet_Data.map((items, idx) => {
            return (
              <div key={idx} className="flex justify-center items-center">
                <p className="text-16">{items.title}</p>
              </div>
            );
          })}
        </div>
      </div>
      <div className="mt-[47px]">
        <p className="text-16 sm:text-18">Your Position:</p>
        <div className="grid grid-cols-2 gap-[21px] mx- mt-[47px]">
          {Position_Data.map((items, idx) => {
            return (
              <div key={idx} className="flex justify-center items-center">
                <p className="text-16">{items.title}</p>
              </div>
            );
          })}
        </div>
      </div>
      <div className="mt-[48px]">
        <p className="text-16 sm:text-18">Execute:</p>
        <div className="flex items-center justify-between w-full mt-[39px]">
          <div className="border-b-[1px] flex items-center gap-[3px] w-[40%]">
            <p className="text-20 sm:text-25">$</p>
            <input placeholder="0" className="bg-none w-full text-18 sm:text-25 focus:outline-none" />
          </div>
          <div className="flex items-center gap-[3px] border-[1px] rounded-[30px] w-fit py-[3px] pl-[15px] pr-[12px]">
            <p className="text-18 sm:text-22">USDC</p>
            <img src="/assets/image/DownArrow.png" className="w-[21px] h-[14px]" />
          </div>
        </div>
      </div>
      <div className="mt-[59px] lg:mt-[100px]">
        <button
          disabled={!write}
           onClick={() => 
            write?.()
            
            // isFetching()
          }
          // onClick={() =>{
          //   console.log('deposit', write)
          //   write()
          // }}
          className="w-full text-16 sm:text-18 rounded-[30px] py-[10px]" style={{ background: "linear-gradient(270deg, #C660C7 0%, #4CC5C0 100%)" }}>
          Deposit
        </button>
        <button className="border-[1px] text-16 sm:text-18 rounded-[30px] py-[10px] w-full mt-[21px] ">
          Withdraw
        </button>
      </div>
    </div>
  );
}
