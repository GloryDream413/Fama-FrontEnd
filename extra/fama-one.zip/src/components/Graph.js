import React from 'react'

export default function Graph() {
  return (
    <div className='mt-[37px] w-full'>
      <img src='/assets/image/Graph.png' className='w-full' />
    </div>
  )
}
