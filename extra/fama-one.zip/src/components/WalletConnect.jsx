import useWalletConnector from '@/hooks/useWalletConnector';
import { conciseAddress } from '@/utils/helper';
// import { conciseAddress } from '@/utils/helper';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useAccount, useDisconnect, useWalletClient } from 'wagmi';

export default function WalletConnect() {
  const router = useRouter();
  const { onConnect } = useWalletConnector();
  const { disconnect, status } = useDisconnect();
  const account = useAccount();
  // console.log({ address: account.address })

  const { data: walletClient, isError, isLoading } = useWalletClient()

  useEffect(() => {
    if (status === 'success') {
      router.push('/');
    }

  }, [status])

  useEffect(() => {
    onConnect()

  }, [isLoading, account?.address, walletClient])

  return (
    <div className="border-[1px] border-nav-sideBorder py-1 px-[25px] text-16 rounded-[43px] md:py-2 cursor-pointer">
      connect wallet
      {/* {account?.address && (<button onClick={() => {
        disconnect()
      }} className="border-[1px] border-nav-sideBorder py-1 px-[25px] text-16 rounded-[43px] md:py-2 cursor-pointer">
        {conciseAddress(account?.address, 6, 5) || 'Wallet Connect'}
      </button>)} */}
      {/* {account?.address ? conciseAddress(account?.address, 6, 5) : 'Wallet Connect'} */}
    </div>
  )
}