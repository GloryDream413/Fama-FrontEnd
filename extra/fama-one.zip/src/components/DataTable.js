import React from "react";

export default function DataTable() {
  const Table_Data = [
    {
      id: 1,
      title: "8/9/23",
      titleTwo: "11:00",
      titleThree: "Hold",
      titleFour: "1672",
      titleFive: "522",
      titleSix: "0",
      titleSeven: "872784",
    },
    {
      id: 2,
      title: "8/9/23",
      titleTwo: "11:00",
      titleThree: "Hold",
      titleFour: "1672",
      titleFive: "522",
      titleSix: "0",
      titleSeven: "872784",
    },
  ];
  return (
    <div>
      <div className="flex items-center gap-[40px] mt-[54px]">
        <p className="text-16 sm:text-20">Activity Logs</p>
        <p className="text-12">Logs are delayed 24hrs</p>
      </div>
      <div className="overflow-auto">
      <div className="flex flex-col min-w-[640px] ">
        <table className="table w-full mt-[17px] ">
          <thead className="text-16 border-b-[1px] text-left ">
            <tr>
              <th>Date</th>
              <th className="text-center">Time</th>
              <th className="text-center">Action</th>
              <th className="text-center">Price</th>
              <th className="text-center">ETH Held</th>
              <th className="text-center">USDC Held</th>
              <th>Total $</th>
            </tr>
          </thead>
          <tbody>
            {Table_Data.map((items, idx) => {
              return (
                <tr key={idx}>
                  <td className="text-16">{items.title}</td>
                  <td className="text-16 text-center">{items.titleTwo}</td>
                  <td className="text-16 text-center">{items.titleThree}</td>
                  <td className="text-16 text-center">{items.titleFour}</td>
                  <td className="text-16 text-center">{items.titleFive}</td>
                  <td className="text-16 text-center">{items.titleSix}</td>
                  <td className="text-16">{items.titleSeven}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        
      </div>
      </div>
      <button className="bg-none w-fit mx-auto text-14 mt-[18px] flex justify-center items-center">
          See all
        </button>
    </div>
  );
}
