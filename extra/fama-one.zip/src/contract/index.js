export { default as contractABI } from './contractAbi.json';
export const contractAddress = "0x6BB762Ab5141A015efD4D6F0723399CAa4A31b07";
export const ensRegistryABI = './contractAbi.json'


export const wagmiContractConfig = { address: contractAddress, abi: ensRegistryABI }